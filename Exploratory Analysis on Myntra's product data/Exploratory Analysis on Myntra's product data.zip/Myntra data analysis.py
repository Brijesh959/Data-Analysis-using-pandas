#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


df1=pd.read_csv("product details.csv")


# In[3]:


df1.head()


# In[4]:


df2=pd.read_csv("products catalog.csv")


# In[5]:


df2.head()


# # merging dataset

# In[6]:


df=pd.merge(df1,df2,left_on='ProductID',right_on='ID',how='inner')


# In[7]:


df.head()


# In[8]:


df.shape


# In[9]:


df=df.drop('ID',axis=1)


# In[10]:


df


# In[11]:


df.info()


# # Renaming column

# In[12]:


df.rename(columns = {'Price (INR)':'Price'}, inplace = True)


# In[13]:


df.info()


# In[14]:


df.columns


# In[15]:


for i in list(df.columns):
    df.rename(columns = {i:i.strip()}, inplace = True)


# # checking for null values

# In[16]:


df.shape


# In[17]:


df.isnull().sum()


# # univariate analysis

# In[18]:


df['ProductID'].unique().shape


# In[19]:


df['ProductName'].unique().shape


# In[20]:


df[df['PrimaryColor'].isnull()]


# In[21]:


df[df['ProductBrand']=='Police']


# In[22]:


df.groupby('Gender').count()


# In[23]:


uc=df.groupby('Gender').count()


# In[24]:


uc


# In[25]:


uc.shape


# In[26]:


k1=uc.index
k1


# In[27]:


df[df['Gender']=='Men']


# In[28]:


s1=[]
s2=[]
for i in k1:
    p=df[df['Gender']==i].groupby('PrimaryColor').count().sort_values(by='ProductID',ascending=False).index[0]
    s1.append(i)
    s2.append(p)
print(s1)
print(s2)


# In[29]:


df=df.fillna('Blue')


# In[30]:


df.isnull().sum()


# In[31]:


df.columns


# In[32]:


df


# In[33]:


# importing required libraries
import seaborn as sns
sns.set()
sns.set(style="darkgrid")


import numpy as np
import pandas as pd

# importing matplotlib
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

import warnings
warnings.filterwarnings("ignore")
plt.rcParams['figure.figsize']=(10,10)


# # CHECKING DISTRIBUTION

# In[34]:



sns.distplot(df['ProductID'])


# In[35]:


sns.distplot(df['Price'])


# In[36]:


df.head()


# # checking for outlier

# In[37]:


sns.boxplot(df['Price'], orient='vertical')


# In[38]:


df[df['Price']>40000]


# In[39]:


sns.boxplot(df['NumImages'], orient='vertical')


# In[40]:


sns.boxplot(df['ProductID'], orient='vertical')


# In[41]:


df.head()


# # Bivariate analysis

# # checking for unique productid

# In[42]:


#checking for unique productid
q=df.groupby('ProductID').count()
q


# # checking for unique productname

# In[43]:


q1=df.groupby('ProductName').count()


# In[ ]:





# In[44]:


q1


# # checking for unique productbrand

# In[45]:



q2=df.groupby('ProductBrand').count()


# In[46]:


q2


# # checking for unique gender

# In[47]:


#checking for unique gender
q3=df.groupby('Gender').count()
q3


# # checking for unique primarycolor

# In[48]:


#checking for unique primarycolor
q4=df.groupby('PrimaryColor').count()
q4


# In[49]:


a2=[q.shape[0],q1.shape[0],q2.shape[0],q3.shape[0],q4.shape[0]]
a2


# In[50]:


df.columns


# In[51]:


a3=['ProductID', 'ProductName', 'ProductBrand', 'Gender','PrimaryColor']
a3


# # columns wise unique records

# In[52]:



sns.barplot(x=a3, y=a2)


# In[53]:


q3


# # unique record in gender columns

# In[54]:



import matplotlib.pyplot as plt
palette_color = sns.color_palette('bright')

  
plt.pie(q3['ProductID'], labels=q3.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[55]:


q4


# # unique record in  columns primarycolor column

# In[56]:


import matplotlib.pyplot as plt
palette_color = sns.color_palette('bright')

  
plt.pie(q4['ProductID'], labels=q4.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[57]:


df


# In[58]:


df[df['Gender']=='Men']


# In[59]:


df.sort_values(by='NumImages',ascending=False)


# In[60]:



W2=df[df['NumImages']==10][['ProductID','ProductName','NumImages']]
W2


# # PRODUCT WHO'S IMAGE IS CAPTURED LARGE NUMBER OF TIMES

# In[61]:



sns.barplot(x=W2['ProductID'],y=W2['NumImages'],hue=W2['ProductName'])


# In[62]:


x1=[]
x2=[]
d1={}
for i in range(10,0,-1):
    d=df[df['NumImages']==i].shape[0]
    d1.update({i:d})
    x1.append(i)
    x2.append(d)
print(d1)
print('x1:',x1)
print('x2:',x2)
    
  


# In[63]:


for i,j in zip(x1,x2):
    if j==max(x2):
        print(i,j)


# # number of product and number of image captured

# In[64]:



sns.barplot(x=x1, y=x2)


# In[65]:


w1=df[df['NumImages']==5]
w1


# In[66]:


w3=w1.groupby('Gender').count()
w3


# # category wise analysis of gender column when numimages=5

# In[67]:



sns.barplot(x=w3.index, y=w3['ProductID'])


# In[68]:


w1


# In[69]:


w4=w1[w1['Gender']=='Men'].groupby('ProductBrand').count().sort_values(by='ProductID',ascending=False).head(10)
w4


# # top 10 product in Men category myntra should look into 

# In[70]:



palette_color = sns.color_palette('bright')

  
plt.pie(w4['ProductID'], labels=w4.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[71]:


w5=w1[w1['Gender']=='Women'].groupby('ProductBrand').count().sort_values(by='ProductID',ascending=False).head(10)
w5


# # top 10 product in Women category myntra should look into 

# In[72]:



palette_color = sns.color_palette('bright')

  
plt.pie(w5['ProductID'], labels=w5.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[73]:


w6=df[df['NumImages']==1]
w6


# In[74]:


w6.shape


# # productbrand which myntra may ignore 

# In[75]:



palette_color = sns.color_palette('bright')

 
plt.pie(w6['Price'], labels=w6['ProductBrand'], colors=palette_color, autopct='%.0f%%')
plt.show()


# In[76]:


w7=w1[w1['Gender']=='Men'].sort_values(by='Price',ascending=False).head(10)
w7


# # top 10 productname in men category throgh which myntra  can earn more profit i.e product with high mrp

# In[77]:



sns.barplot(y=w7['Price'], x=w7['ProductID'],hue=w7['ProductName'])


# In[78]:


w8=w1[w1['Gender']=='Women'].sort_values(by='Price',ascending=False).head(10)
w8


# # top 10 productname in Women category throgh which myntra  can earn more profit i.e product with high mrp

# In[79]:



sns.barplot(y=w8['Price'], x=w8['ProductID'],hue=w8['ProductName'])


# In[80]:


w1


# In[81]:


w1.groupby('Gender').count()


# In[82]:


a10=w1.groupby('Gender').count().index
a10


# # top 10 product gender category wise into which myntra should look 

# In[83]:



for i in a10:
    w11=w1[w1['Gender']==i].groupby('ProductBrand').count().sort_values(by='ProductID',ascending=False).head(10)
    print(i)
    palette_color = sns.color_palette('bright')
    plt.pie(w11['ProductID'], labels=w11.index, colors=palette_color, autopct='%.0f%%')
    plt.show()
    print('*************************************************************************************************************')


# In[84]:


w1


# In[85]:


z5=w1[w1['Gender']=='Men']
z5


# In[86]:


z5['ProductBrand'].mode()[0]


# In[87]:


z5[z5['ProductBrand']=='Indian Terrain'].shape[0]


# In[88]:


a10


# In[89]:


r2=[]
r3=[]
r4=[]
for i in a10:
    z6=w1[w1['Gender']==i]
    r1=z6['ProductBrand'].mode()[0]
    r5=z6[z6['ProductBrand']==r1].shape[0]
    r2.append(i)
    r3.append(r1)
    r4.append(r5)
print('r2:',r2)
print('r3:',r3)
print('r4:',r4)


# # gender category wise brand into which myntra should look

# In[90]:



sns.barplot(y=r4, x=r2,hue=r3)


# In[ ]:




