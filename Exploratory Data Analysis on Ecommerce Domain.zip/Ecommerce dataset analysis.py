#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


df=pd.read_csv('ecom_data.csv',encoding= 'unicode_escape')


# In[3]:


df.info()


# In[4]:


df.head()


# In[5]:


df.tail()


# In[6]:


df.shape


# In[7]:


df.columns


# In[ ]:





# In[8]:


df['CustomerID'].replace('NaN',np.nan)
df['Description'].replace('NaN',np.nan)


# # checking for null values

# In[9]:


df.isnull().sum()


# In[10]:


(df.isnull().sum()*100)/(df.shape[0])


# In[11]:


df=df.loc[df['Description'].notnull()] #droping rows which has null value in Description column


# In[12]:


df


# In[13]:


df.isnull().sum()


# In[14]:


df.head()


# In[15]:


df[df['CustomerID'].isnull()]


# In[16]:


K=df[df['CustomerID'].isnull()].Country.unique()
K


# In[17]:


for i in K:
    l=df.loc[(df['Country']==i) & (df['CustomerID'].notnull()),('Description','CustomerID')]
    print(i)
    print('total unique customer:',l.CustomerID.nunique())
    print('total unique product:',l.Description.nunique())
    print('total no of not null record:',l.shape[0])
    l1=df.loc[(df['Country']==i) & (df['CustomerID'].isnull()),('Description','CustomerID')]
    print('total no of null record:',l1.shape[0])
    print('total no of record:',l.shape[0]+l1.shape[0])
    print('********')


# In[18]:


df.head()


# In[19]:


df[df['CustomerID'].isnull()]


# In[20]:


df


# In[21]:



K
    


# In[22]:


d=df[df['CustomerID'].notnull()].Country.unique()
d


# In[23]:


K


# In[24]:


k=list(K)
k


# In[25]:


l1=k.pop(4)
l1


# In[26]:


k


# In[27]:


p1=df[df['CustomerID'].notnull()]


# In[28]:


r=[]
s=[]
t={}
for i in k:
    c=p1.loc[p1['Country']==i]
    h=c['CustomerID'].mode()[0]
    r.append(i)
    s.append(h)
    t.update({i:h})
print(r)
print(s)
print(t)


# In[29]:


print(r)
print(s)


# In[30]:


for i,j in zip(r,s):
    z=(df['Country']==i) & (df['CustomerID'].isnull())
    df.loc[z,'CustomerID']=j
    


# In[31]:


df


# In[32]:


df.isnull().sum()


# In[33]:


df1=df[df['Country']!='Hong Kong']


# In[34]:


df1


# In[35]:


df1.isnull().sum() # achieved dataframe without null value


# In[36]:


nd=df1


# In[37]:


nd


# In[38]:


nd.isnull().sum()


# # checking for outlier

# In[39]:


nd.describe()


# In[40]:


a=nd.describe().columns


# In[41]:


a=list(a)


# In[42]:


# importing required libraries
import numpy as np
import pandas as pd

# importing matplotlib
import matplotlib.pyplot as plt

# display plots in the notebook itself
get_ipython().run_line_magic('matplotlib', 'inline')


# In[43]:


# importing required libraries
import seaborn as sns
sns.set()
sns.set(style="darkgrid")


import numpy as np
import pandas as pd

# importing matplotlib
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

import warnings
warnings.filterwarnings("ignore")
plt.rcParams['figure.figsize']=(10,10)


# In[44]:


sns.boxplot(nd['Quantity'], orient='vertical')


# In[45]:


nd['Quantity'] = np.where(nd['Quantity']<0, (-1)*nd['Quantity'], nd['Quantity'])


# In[46]:


nd


# In[47]:


sns.boxplot(nd['Quantity'], orient='vertical')


# In[48]:


nd=nd[nd['Quantity']<15000]


# In[49]:


nd


# sns.boxplot(nd['Quantity'], orient='vertical')

# In[50]:


nd.isnull().sum()


# In[51]:


nd.describe()


# # Univariate Analysis

# # analysing unit price

# In[52]:


sns.boxplot(nd['UnitPrice'], orient='vertical')


# In[53]:


nd.describe()


# In[54]:


nd[nd['UnitPrice']<0]


# In[55]:


nd['UnitPrice'] = np.where(nd['UnitPrice']<0, (-1)*nd['UnitPrice'], nd['UnitPrice'])


# In[56]:


sns.boxplot(nd['UnitPrice'], orient='vertical')


# In[57]:


nd=nd[nd['UnitPrice']<35000]


# In[58]:


nd


# In[59]:


sns.boxplot(nd['UnitPrice'], orient='vertical')


# In[60]:


nd.describe()


# ## analysing customerid

# In[61]:


nd.describe()


# In[62]:


sns.boxplot(nd['CustomerID'], orient='vertical')


# In[63]:


# all numerical column has been analysed


# In[64]:


nd


# In[65]:


nd.isnull().sum()


# In[66]:


nd.head()


# # Bivariate analysis

# In[67]:


nd.corr()


# In[68]:


sns.heatmap(nd.corr())


# # Analysing dataframe for good insight

# In[69]:


nd.head()


# In[70]:


s1=nd.groupby(['Description'])


# In[71]:


s1


# In[72]:


s3=s1.count().sort_values(by='CustomerID', ascending=False).head()


# # top 5 product

# In[73]:



s3


# In[74]:


s3['CustomerID'].values


# In[75]:


s3.index


# In[76]:


import matplotlib.pyplot as plt
palette_color = sns.color_palette('bright')

  
plt.pie(s3['CustomerID'].values, labels=s3.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[77]:


s4=s1.count().sort_values(by='CustomerID', ascending=True).head()


# # product that buyed minimum by the customer

# In[78]:



s4


# In[79]:


s4['CustomerID'].values


# In[80]:


s4.index


# In[81]:


import matplotlib.pyplot as plt
palette_color = sns.color_palette('bright')

  
plt.pie(s4['CustomerID'].values, labels=s4.index, colors=palette_color, autopct='%.0f%%')
plt.show()


# In[82]:


nd.head()


# In[83]:


nd['CustomerID'].values.shape[0]


# In[84]:


nd['CustomerID'].unique().shape[0]


# In[85]:


a1=nd.groupby('CustomerID').count().sort_values(by='Description',ascending=False)


# # top 5 customer who shops more product

# In[86]:



a2=a1.head()
a2


# In[87]:


sns.barplot(x=a2.index, y=a2['InvoiceNo'], data=a2)


# In[88]:


nd.head()


# In[89]:


q1=nd.groupby('Country').count().sort_values(by='Quantity',ascending=False).head()
q1


# # top 5 country most profitable to ecom company

# In[90]:



sns.barplot(x=q1.index, y=q1['InvoiceNo'], data=q1)


# In[91]:


nd


# In[92]:


nd['total_amount']=nd['Quantity']*nd['UnitPrice']


# In[93]:


nd


# In[94]:


nd.tail()


# In[95]:


nd.info()


# In[96]:


nd.head()
    


# In[97]:


nd.shape[0]


# In[98]:


nd.groupby('Country').sum()


# In[99]:


k5=[]
for i in range(nd.shape[0]):
    if 'C' in nd.iloc[i,0]:
        k5.append(nd.iloc[i,0])
print(k5)
        
        
    
    
    


# In[100]:


len(k5)


# In[ ]:





# In[101]:


k6=np.array(k5)
k6


# In[102]:


k6.shape[0]


# In[103]:


np.unique(k6)


# In[104]:


np.unique(k6).shape[0]


# In[105]:


nd[nd['InvoiceNo']=='C536822']


# In[106]:


k6


# In[107]:


nd.head()


# In[108]:


for i in range(nd.shape[0]):
    if nd.iloc[i,0] in k6:
        nd.iloc[i,-1]=(-1)*nd.iloc[i,-1]
        


# In[109]:


nd[nd['InvoiceNo']=='C536850']


# In[110]:


nd.head()


# In[111]:


w1=nd.groupby('Country').sum()
w1


# In[112]:


w1.head()


# In[113]:


nd.info()


# In[114]:


nd.head()


# In[115]:


nd[nd['InvoiceNo']=='C536850']


# In[116]:


nd.info()


# In[117]:


nd.loc[nd['total_amount']<0,'os']='C'
nd.loc[nd['total_amount']>0,'os']='NC'


# In[118]:


nd.head()


# In[119]:


d1=nd.groupby(['Country','os']).count()
d1


# In[120]:


d2=nd.groupby(['Country','os']).sum()
d2


# In[121]:


d3=nd.groupby(['Country','os'])['total_amount'].sum()
d3


# In[122]:


d4=d3.reset_index()
d4


# # countrywise amount of cancelled and not cancelled order

# In[123]:



for i in range(0,66,2):
    sns.barplot(x='Country', y='total_amount',data=d4[i:i+2])
    plt.show()


# In[124]:


d2


# In[125]:


d2.reset_index()


# In[126]:


d5=d2.groupby('Country').count()
d5


# In[127]:


d5.reset_index()


# In[128]:


d6=d5[d5.Quantity<2].index


# # Country who never cancelled order

# In[129]:



d6=list(d6)
d6


# In[130]:


nd.head()


# In[131]:


r1=[]
for i in d6:
    p2=nd[nd['Country']==i]['total_amount'].sum()
    r1.append(p2)
print(r1)


# In[132]:


d6


# # country and amount who never cancelled order

# In[133]:



sns.barplot(x=d6, y=r1)


# In[ ]:




